<?php
session_start();

if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
}
if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
}
?>
<!doctype html>
<html lang="en">
<head>
    <title>Ebooks</title>
    <link rel="stylesheet" href="styles/files.css" />
    <?php include "header.php";
    ?>
    <style>
        .content a:hover{
            background-color: #eeeeee;
            color: #ff5722;
        }
    </style>
</head>
<body>
<section id="header-section">
    <div class="container-fluid">
        <?php include "navbar.php";
        ?>
    </div>
</section>

    <h1 class="notes">E-BOOKS</h1>
    <hr class="top"/>
    <section class="sec" style="text-align: left">
        <div class="subject">
            <button type="button" class="collapsible">Machine Learning</button>
            <div class="content">
                <a href="#">file1</a>
                <a href="#">file2</a>
                <a href="#">file3</a>
            </div>
        </div>
        <hr/>
        <div class="subject">
            <button type="button" class="collapsible">Artificial Intelligence</button>
            <div class="content">
                <a href="test.txt" download="file1">test file</a>
                <a href="#">file2</a>
                <a href="#">file3</a>
            </div>
        </div>
        <hr/>
        <div class="subject">
            <button type="button" class="collapsible">MATLAB</button>
            <div class="content">
                <a href="#">file1</a>
                <a href="#">file2</a>
                <a href="#">file3</a>
            </div>
        </div>
        <hr/>
        <div class="subject">
            <button type="button" class="collapsible">Advanced JAVA</button>
            <div class="content">
                <a href="#">file1</a>
                <a href="#">file2</a>
                <a href="#">file3</a>
            </div>
        </div>
        <hr/>
        <div class="subject">
            <button type="button" class="collapsible">Block Chain</button>
            <div class="content">
                <a href="#">file1</a>
                <a href="#">file2</a>
                <a href="#">file3</a>
            </div>
        </div>
        <hr/>
        <div class="subject">
            <button type="button" class="collapsible">Cyber Security</button>
            <div class="content">
                <a href="#">file1</a>
                <a href="#">file2</a>
                <a href="#">file3</a>
            </div>
        </div>
        <hr/>
    </section>
<?php include "footer.php";
?>
    <script>
        let coll = document.getElementsByClassName("collapsible");
        let i;
        for (i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function () {
                this.classList.toggle("active");
                let content = this.nextElementSibling;
                if (content.style.display === "block") {
                    content.style.display = "none";
                } else {
                    content.style.display = "block";
                }
            });
        }
    </script>
</body>
</html>