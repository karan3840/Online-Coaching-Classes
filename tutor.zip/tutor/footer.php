<!-- Footer -->

<footer id="footer">
    <div class="container-fluid">
        <i class="footer-icon fab fa-twitter"></i>
        <i class="footer-icon fab fa-facebook-f"></i>
        <i class="footer-icon fab fa-instagram"></i>
        <i class="footer-icon fas fa-envelope"></i>
        <p id="copyright">© Copyright 2020 Educom</p>
    </div>
</footer>